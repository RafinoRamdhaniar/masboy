from flask import Flask, redirect, render_template, request, url_for, session
from flask_mysqldb import MySQL
import mysql.connector
app = Flask(__name__)

app.secret_key = '541793'
app.config['SECRET_KEY'] = '@#$123456&*()'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'hima'
# Initialize MySQL
mysql = MySQL(app)


# Default URL
@app.route('/', methods=["GET", "POST"])
def home():
    res = 0
    if request.method == 'POST' and 'txtUsername' in request.form and 'txtPassword' in request.form:
        username = request.form['txtUsername']
        password = request.form['txtPassword']

        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM akun WHERE username = %s AND password = %s', (username,password))
        account = cursor.fetchone()

        if account:
            session.permanent = True
            session['id_pengguna'] = account[0]
            res=200
            return redirect(url_for('data'))
        else:
            res=100

    return render_template('login.html', msg=res)

@app.route('/register', methods=["GET", "POST"])
def register():
    res = []
    if request.method == 'POST':

        nama = request.form['txtNama']
        no_hp = request.form['txtNoHp']
        email = request.form['txtEmail']
        alamat = request.form['txtAlamat']
        username = request.form['txtUsername']
        password = request.form['txtPassword']
        
        cursor = mysql.connection.cursor()
        cursor.execute('''INSERT INTO akun(username,PASSWORD,email,nama,no_hp,alamat) VALUES(%s,%s,%s,%s,%s,%s)''',(username,password,email,nama,no_hp,alamat))
        mysql.connection.commit()
        res.extend([email,nama,no_hp,alamat])

    return render_template('register.html', msg = res)

@app.route('/data', methods=["GET", "POST"])
def data():
    if session.get('id_pengguna'):
        cursor = mysql.connection.cursor()
        cursor.execute('''SELECT * FROM akun''')
        data = cursor.fetchall()
        # data = getPengguna()
        return render_template('data.html', data=data)
    else:
        return render_template('login.html')

@app.route('/delete/<id_pengguna>', methods=["POST"])
def delete(id_pengguna):
    if session.get('id_pengguna') and request.method == 'POST':
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM akun WHERE id_pengguna = %s', (id_pengguna,))
        mysql.connection.commit()
            
        return redirect(url_for('data'))

@app.route('/update/<id_pengguna>', methods=['GET','POST'])
def update(id_pengguna):
    if session.get('id_pengguna') and request.method == 'POST':

        nama = request.form['txtNama']
        alamat = request.form['alamat']
        cursor = mysql.connection.cursor()
        cursor.execute('UPDATE akun SET nama = %s, alamat = %s WHERE id_pengguna = %s',(nama,alamat,id_pengguna,))
        mysql.connection.commit()

        return redirect(url_for('data'))

@app.route('/logout', methods=["GET"])
def logout():
    session.pop('id_pengguna')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)